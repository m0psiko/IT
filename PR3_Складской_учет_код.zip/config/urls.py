"""
URL configuration for config project.
"""
from django.contrib import admin
from django.urls import path
from apps.catalog.views import warehouse_dashboard

# Брендирование панели управления под складской учёт
admin.site.site_header = "Программа складского учёта"
admin.site.site_title = "Складской учёт (WMS)"
admin.site.index_title = "Панель управления складским учётом"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', warehouse_dashboard, name='warehouse_dashboard'),
]

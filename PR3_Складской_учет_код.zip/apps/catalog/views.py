from django.shortcuts import render
from .models import Location, Category, Vendor, Model
from apps.accounts.models import User


def warehouse_dashboard(request):
    locations = Location.objects.all()
    categories = Category.objects.all()
    vendors = Vendor.objects.all()
    models = Model.objects.select_related('vendor', 'category').all()
    users = User.objects.filter(is_active=True).order_by('role')

    selected_cat = request.GET.get('category')
    if selected_cat:
        models = models.filter(category_id=selected_cat)

    context = {
        'locations': locations,
        'categories': categories,
        'vendors': vendors,
        'models': models,
        'users': users,
        'total_items': Model.objects.count(),
        'total_locations': locations.count(),
        'total_categories': categories.count(),
        'total_vendors': vendors.count(),
        'total_users': users.count(),
        'selected_cat': selected_cat,
    }
    return render(request, 'index.html', context)
